console.log('Interface Script Loaded.');

// parameters
const addRate = 100; // ms
const numberOfDots = 10;
const loaderAnimationTime = addRate * numberOfDots; // ms
const removeRate = loaderAnimationTime * 1.75; // ms
const loaderDuration = addRate * numberOfDots + removeRate; // 2.75 seconds
const requestDuration = loaderDuration * 12; // 30X loader duration ~33 seconds

// global state variables
let dotInterval = {};
let dotIntervalReset = {};
let dotCount = 1;
let debounceRequest = {};
let errorTimeout = {};

// data structures
const connectionStatus = [
    'offline',
    'online'
];

const keyModules = ['trigonomic', 'geometric', 'combinatoric', 'statistical', 'algebraic'];

let INFORMATION = {};

const error = {
    emptyString: 'Invalid: empty string',
    parenthesis: 'Invalid: parenthesis',
    operation: 'Invalid: operation',
    connectionFailed: 'Error: connection failed',
    connectionTimeout: 'Error: connection attempt timed out',
    dataNotFound: 'Error: data not found',
    DOMElement: 'Error: DOM element not found',
};

// operation characters
const operations = {
    addition: '+',
    subtraction: '-',
    multiplication: '*',
    division: '/',
    exponentiation: '^',
    radication: '√',
};

// DOM selections
const DOMSelection = {
    'connectionStatusDisplay': () => {return document.querySelector('#connection-status')},
    'loaderElement': () => {return document.querySelector('.elipses-container')},
    
    'problemField': () => {return document.querySelector('#problem-field')},
    'answerField': () => {return document.querySelector('#answer-field')},
    'evalBTN': () => {return document.querySelector('#evaluate-button')},

    'searchType': () => {return document.querySelector('#search-type')},
    'searchField': () => {return document.querySelector('#search-field')},
    'resultContainer': () => {return document.querySelector('#search-result-container')},
    'searchBTN': () => {return document.querySelector('#search-button')},
};

function DOMit(elementName) {
    // tests for existence of an element using selector stored in DOMSelection structure at the given element name
    // returns DOM element or false boolean value
    const funct = DOMSelection[`${elementName}`];
    if (funct === null || funct === undefined) {
        console.error(error.DOMElement);
        return false;
    } else {
        const el = funct();
        if (el === null || el === undefined) {
            console.error(error.DOMElement);
            return false;
        } else {
            return el;
        }
    }
};

// update dom data
const loaderElement = DOMit('loaderElement');
if (loaderElement) {
    loaderElement.setAttribute('style', `--anim-time: ${loaderAnimationTime}ms`);
}

// loader animation
function startLoader() {

    // add dot
    const dot = document.createElement('div');
    dot.classList.add('elipses-dot');
    const loaderElement = DOMit('loaderElement');
    if (loaderElement) {
        loaderElement.appendChild(dot);
    }

    clearInterval(dotInterval);
    dotInterval = setInterval(() => {
        if (dotCount < numberOfDots) {

            // add dot
            const dot = document.createElement('div');
            dot.classList.add('elipses-dot');
            const loaderElement = DOMit('loaderElement');
            if (loaderElement) {
                loaderElement.appendChild(dot);
            }

            dotCount += 1;
        } else {
            clearInterval(dotInterval);
            dotCount = 1;
            dotIntervalReset = setTimeout(() => {
                clearTimeout(dotIntervalReset);
                const loaderElement = DOMit('loaderElement');
                if (loaderElement) {
                    loaderElement.innerHTML = '';
                }
                startLoader();
            }, removeRate);
        }
    }, addRate);
};

function stopLoader() {
    clearInterval(dotInterval);
    clearTimeout(dotIntervalReset);
    dotCount = 1;
    const loaderElement = DOMit('loaderElement');
    if (loaderElement) {
        loaderElement.innerHTML = '';
    }
};

// problem string validation
function serveError(error) {
    // displays string in error argument on page for 3000 ms
    const answer = DOMit('answerField');
    if (answer) {
        // display error
        answer.innerText = error;

        // correct answer clipping on overflow
        if (answer.scrollHeight > answer.clientHeight || answer.scrollWidth > answer.clientWidth) {
            answer.setAttribute('style', 'justify-content: flex-start');
        } else {
            answer.setAttribute('style', 'justify-content: center');
        }

        // focus on error
        answer.focus();

    }
    clearTimeout(errorTimeout);
    errorTimeout = setTimeout(() => {
        clearTimeout(errorTimeout);
        const answer = DOMit('answerField');
        if (answer) {
            answer.innerText = '';
        }
    }, 10000);
};

function validParen(prob) {
    // post-validates parenthesis in problem string
    let nestLvl = 0;
    let parens = [];
    for (let i = 0; i < prob.length; i++) {
        if (prob[i] === '(') {
            parens.push('(');
            nestLvl += 1;
        } else if (prob[i] === ')') {
            parens.push(')');
            nestLvl -= 1;
        }
    }
    // if there are parenthesis
    if (parens.length > 0) {
        if (nestLvl !== 0) {
            // no non-zero sum of nestLvl
            serveError(error.parenthesis);
            return false;
        } else if (parens[0] === ')') {
            // no closing paren at start
            serveError(error.parenthesis);
            return false;
        } else if (parens[parens.length - 1] === '(') {
            // no opening paren at end
            serveError(error.parenthesis);
            return false;
        } else {
            // match each open paren to a closing paren (accounting for nesting)
            for (let i = 0; i < prob.length; i++) {
                if (prob[i] === '(') {
                    // search for match
                    let x = 0;
                    for (let j = i; j < prob.length; j++) {
                        if (prob[j] === ')') {
                            x -= 1;
                        } else if (prob[j] === "(") {
                            x += 1;
                        }
                        if (x === 0) {
                            break;
                        }
                    }
                    if (x !== 0) {
                        // missing match
                        serveError(error.parenthesis);
                        return false;
                    }
                }
            }
        }
        return true;
    } else {
        // can't test parens format with no parens
        return true;
    }
};

function isOp(index, prob) {
    // tests if character at index in prob string is an operation
    if (index < prob.length) {
        const char = prob.substring(index, index + 1);
        const values = Object.values(operations);
        for (let i = 0; i < values.length; i++) {
            if (char === values[i]) {
                // found a match
                return true;
            }
        }
        // none matched
        return false;
    }
};

function validOp(prob) {
    // post-validates operations in problem string

    // test for operations on start or end of problem
    if (isOp(0, prob) && prob[0] !== operations.radication || isOp(prob.length - 1, prob)) {
        serveError(error.operation);
        return false;
    } else {
        for (let i = 0; i < prob.length; i++) {
            // consecutive operations test
            if (isOp(i, prob) && i + 1 < prob.length && isOp(i + 1, prob)) {
                // no consecutive operations
                serveError(error.operation);
                return false;
            }
        }
        // if nothing returns false
        return true;
    }
};

// Evaluate problem string by request to Eval API
function evalReq() {
    // test for internet connection
    if (window.navigator.onLine === true) {
        // debounce to prevent excessive requests
        clearTimeout(debounceRequest);
        debounceRequest = setTimeout(() => {
            // debounced
            clearTimeout(debounceRequest);
            
            // get problem string
            const problem = DOMit('problemField')?.value;
            
            // validate problem
            let valid = false;
            
            // run empty string test
            if (problem === null || problem === undefined || problem.length === 0) {

                // empty string
                serveError(error.emptyString);

            } else {
                
                // non-empty string

                // run parenthesis test
                if (validParen(problem)) {
                    // valid parenthesis
                    
                    // run operation test
                    if (validOp(problem)) {
                        // add further validation here; before "valid = true"
                        valid = true;
                    }
                }
            }

            // make request if valid
            if (valid) {
                // 3 cases of request
                    // Case 1: responds with answer
                    // Case 2: responds with error
                    // Case 3: connection timeout

                // start loader
                startLoader();

                // start connection timeout
                const root = 'https://eval-api-8ece55f267c1.herokuapp.com/';
                const controller = new AbortController();

                // Case 3: Connection timeout
                const connectionTimeout = setTimeout(() => {

                    // abort request
                    controller.abort();

                    // stop loader
                    stopLoader();

                    // update answer field with error message
                    serveError(error.connectionTimeout);

                    // cleanup cache
                    clearTimeout(connectionTimeout);

                }, requestDuration);
                

                // fetch request to Eval API
                try {
                    fetch(`${root}/eval/answer`, {
                        method: 'POST',
                        signal: controller.signal,
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ problem: problem, use_logs: "0" })
                    })
                    .then(response => response.json())
                    .then((data) => {
                        
                        // Case 1: responds with answer

                        // cancel connection timeout
                        clearTimeout(connectionTimeout);

                        // store data in temporary variable
                        const dat = data;

                        // select answer field
                        const answer = DOMit('answerField');
                        if (answer) {
                            // update answer field with answer in response
                            answer.innerText = dat;
    
                            // correct answer clipping on overflow
                            if (answer.scrollHeight > answer.clientHeight || answer.scrollWidth > answer.clientWidth) {
                                answer.setAttribute('style', 'justify-content: flex-start');
                            } else {
                                answer.setAttribute('style', 'justify-content: center');
                            }
    
                            // focus on output field
                            answer.focus();
                        }

                        // stop loader
                        stopLoader();

                    })

                } catch {
                    
                    // Case 2: responds with error

                    // cancel connection timeout
                    clearTimeout(connectionTimeout);

                    // stop loader after a single duration
                    stopLoader();

                    // update answer field with error message
                    serveError(error.connectionFailed);
                }
            }

        }, 1000);


    } else {
        // highlight connection status
        const connectionStatusDisplay = DOMit('connectionStatusDisplay');
        if (connectionStatusDisplay) {
            connectionStatusDisplay.style.color = '#a90d00';
        }
        const x = setTimeout(() => {
            clearTimeout(x);
            const connectionStatusDisplay = DOMit('connectionStatusDisplay');
            if (connectionStatusDisplay) {
                connectionStatusDisplay.style.color = '#2fff2f';
            }
        }, 1000);
    }
};

// gets + displays result from search in INFOMRATION structure
function copyButton(string) {
    // creates a button which copies string to clipboard when pressed
    const button = document.createElement('button');
    button.setAttribute('class', 'copy-button-style');
    button.innerText = '❐';
    button.addEventListener('click', () => {
        navigator.clipboard.writeText(string);
        button.innerText = '✔';
    });
    return button;
};

function searchResult() {

    // console.log(INFORMATION);

    // ensure loader stops
    stopLoader();
    
    // get query data
    const searchField = DOMit('searchField');
    const query = searchField.value.toUpperCase();

    // clear previous info
    const resultContainer = DOMit('resultContainer');
    resultContainer.innerHTML = '';

    // use query to search through data
    if (query === 'INFO') {
        // returns all program info

        // build elements for display format
        const headTitle = document.createElement('h2');
        headTitle.innerText = 'Program Information';
        
        const constantTitle = document.createElement('h3');
        constantTitle.innerText = 'Constants';

        const operationTitle = document.createElement('h3');
        operationTitle.innerText = 'Operations';
        
        const variablesTitle = document.createElement('h3');
        variablesTitle.innerText = 'Valid Variables';

        const keysTitle = document.createElement('h3');
        keysTitle.innerText = 'Key Functions';

        // assemble and append elements to display
        resultContainer.appendChild(headTitle);
        
        resultContainer.appendChild(addSpace());
        resultContainer.appendChild(constantTitle);
        resultContainer.appendChild(addSpace());
        for (let i = 0; i < INFORMATION.constants.length; i++) {
            // create container
            const container = document.createElement('div');

            // build name
            const name = document.createElement('div');
            name.innerText = `Name: ${INFORMATION.constants[i].name}`;

            // build syntax
            const syntax = document.createElement('div');
            syntax.style.display = 'flex';
            syntax.style.justifyContent = 'center';
            syntax.style.alignItems = 'center';
            syntax.innerText = `Syntax: ${INFORMATION.constants[i].syntax}`;
            const copy = copyButton(INFORMATION.constants[i].syntax);
            syntax.appendChild(copy);

            // build value
            const value = document.createElement('div');
            value.innerText = `Value: ${INFORMATION.constants[i].value}`;

            // assemble and add
            container.appendChild(name);
            container.appendChild(syntax);
            container.appendChild(value);
            resultContainer.appendChild(container);
            resultContainer.appendChild(addSpace())
        }
        
        resultContainer.appendChild(addSpace());
        resultContainer.appendChild(operationTitle);
        resultContainer.appendChild(addSpace());
        for (let i = 0; i < INFORMATION.operations.length; i++) {
            const container = document.createElement('div');
            // build name
            const name = document.createElement('div');
            name.innerText = `Name: ${INFORMATION.operations[i].name}`;
            // build syntax
            const syntax = document.createElement('div');
            syntax.style.display = 'flex';
            syntax.style.justifyContent = 'center';
            syntax.style.alignItems = 'center';
            syntax.innerText = `Syntax: ${INFORMATION.operations[i].syntax}`;
            const copy = copyButton(INFORMATION.operations[i].syntax);
            syntax.appendChild(copy);
            // assemble and add
            container.appendChild(name);
            container.appendChild(syntax);
            resultContainer.appendChild(container);
            resultContainer.appendChild(addSpace());
        }
        
        resultContainer.appendChild(addSpace());
        resultContainer.appendChild(variablesTitle);
        resultContainer.appendChild(addSpace());
        const vars = document.createElement('div');
        vars.innerText = INFORMATION.variables.join(', ');
        resultContainer.appendChild(vars);
        resultContainer.appendChild(addSpace());

        resultContainer.appendChild(addSpace());
        resultContainer.appendChild(keysTitle);
        resultContainer.appendChild(addSpace());
        for (let i = 0; i < INFORMATION.key_functions.length; i++) {
            for (let j = 0; j < INFORMATION.key_functions[i].length; j++) {
                const container = document.createElement('div');
                const obj = INFORMATION.key_functions[i][j];
                // build name
                const name = document.createElement('div');
                name.innerText = `Name: ${obj.name}`;
                // build key
                const key = document.createElement('div');
                key.innerText = `Keyword: ${obj.key}`;
                // build syntax
                const syntax = document.createElement('div');
                syntax.style.display = 'flex';
                syntax.style.justifyContent = 'center';
                syntax.style.alignItems = 'center';
                syntax.innerText = `Syntax: ${obj.syntax}`;
                const copy = copyButton(obj.syntax);
                syntax.appendChild(copy);
                // build about
                const about = document.createElement('div');
                about.style.padding = '0vw 20vw';
                about.innerText = `Description: ${obj.about}`;
                // assemble and add
                container.appendChild(name);
                container.appendChild(key);
                container.appendChild(syntax);
                container.appendChild(about);
                resultContainer.appendChild(container);
                resultContainer.appendChild(addSpace());
            }
        }
        resultContainer.appendChild(addSpace());

    } else {
        // search for specific function
        const searchType = DOMit('searchType');
        if (searchType) {
            const searchTypeValue = searchType.value;
            let searching = true;
            if (searchTypeValue=== 'search-type-name') {
                for (let module of INFORMATION.key_functions) {
                    for (let obj of module) {
                        if (obj.name.toUpperCase() === query) {
                            // build elements for display format
                            const headTitle = document.createElement('h3');
                            headTitle.innerText = `The ${obj.name} Key Function`;
                            // build key
                            const key = document.createElement('div');
                            key.innerText = 'Keyword: ' + obj.key;
                            // build syntax
                            const syntax = document.createElement('div');
                            syntax.style.display = 'flex';
                            syntax.style.justifyContent = 'center';
                            syntax.style.alignItems = 'center';
                            syntax.innerText = 'Syntax: ' + obj.syntax;
                            syntax.appendChild(copyButton(obj.syntax));
                            // build about
                            const about = document.createElement('div');
                            about.style.padding = '0vw 20vw';
                            about.innerText = 'Description: ' + obj.about;
                            // assemble and add
                            resultContainer.appendChild(headTitle);
                            resultContainer.appendChild(addSpace());
                            resultContainer.appendChild(key);
                            resultContainer.appendChild(addSpace());
                            resultContainer.appendChild(syntax);
                            resultContainer.appendChild(addSpace());
                            resultContainer.appendChild(about);
                            resultContainer.appendChild(addSpace());

                            searching = false;
                            break;
                        }
                    }
                    if (!searching) {
                        break;
                    }
                }

            } else if (searchTypeValue === 'search-type-key') {
                for (let module of INFORMATION.key_functions) {
                    for (let obj of module) {
                        if (obj.key.toUpperCase() === query) {
                            // build elements for display format
                            const headTitle = document.createElement('h3');
                            headTitle.innerText = `The ${obj.name} Key Function`;
                            // build key
                            const key = document.createElement('div');
                            key.innerText = 'Keyword: ' + obj.key;
                            // build syntax
                            const syntax = document.createElement('div');
                            syntax.style.display = 'flex';
                            syntax.style.justifyContent = 'center';
                            syntax.style.alignItems = 'center';
                            syntax.innerText = 'Syntax: ' + obj.syntax;
                            syntax.appendChild(copyButton(obj.syntax));
                            // build about
                            const about = document.createElement('div');
                            about.style.padding = '0vw 20vw';
                            about.innerText = 'Description: ' + obj.about;

                            resultContainer.appendChild(headTitle);
                            resultContainer.appendChild(addSpace());
                            resultContainer.appendChild(key);
                            resultContainer.appendChild(addSpace());
                            resultContainer.appendChild(syntax);
                            resultContainer.appendChild(addSpace());
                            resultContainer.appendChild(about);
                            resultContainer.appendChild(addSpace());

                            searching = false;
                            break;
                        }
                    }
                    if (!searching) {
                        break;
                    }
                }

            } else if (searchTypeValue === 'search-type-module') {
                let index = 0;
                for (mod of keyModules) {
                    if (query === mod.toUpperCase()) {
                        searching = false;
                        break;
                    } else {
                        index += 1;
                    }
                }
                if (searching) {
                    // serve module name error
                    const error = document.createElement('div');
                    error.innerText = 'No Key Function Module by that name.\n\nModule Names:\n';
                    for (mod of keyModules) {
                        const div = document.createElement('div');
                        div.style.display = 'flex';
                        div.style.justifyContent = 'center';
                        div.style.alignItems = 'center';
                        div.innerText = `${mod}\n`;
                        div.appendChild(copyButton(mod));
                        error.appendChild(div);
                    }
                    resultContainer.appendChild(error);
                    searching = false;
                } else {
                    for (let obj of INFORMATION.key_functions[index]) {
                        // build elements for display format
                        const headTitle = document.createElement('h3');
                        headTitle.innerText = `The ${obj.name} Key Function`;

                        const key = document.createElement('div');
                        key.innerText = 'Keyword: ' + obj.key;

                        const syntax = document.createElement('div');
                        syntax.style.display = 'flex';
                        syntax.style.justifyContent = 'center';
                        syntax.style.alignItems = 'center';
                        syntax.innerText = 'Syntax: ' + obj.syntax;
                        syntax.appendChild(copyButton(obj.syntax));

                        const about = document.createElement('div');
                        about.style.padding = '0vw 20vw';
                        about.innerText = 'Description: ' + obj.about;

                        resultContainer.appendChild(headTitle);
                        resultContainer.appendChild(addSpace());
                        resultContainer.appendChild(key);
                        resultContainer.appendChild(addSpace());
                        resultContainer.appendChild(syntax);
                        resultContainer.appendChild(addSpace());
                        resultContainer.appendChild(about);
                        resultContainer.appendChild(addSpace());
                        resultContainer.appendChild(addSpace());
                    }
                }

            } else if (searchTypeValue === 'search-type-error') {
                // search through errors property of INFORMATION and display matching error
                let error = {};

                // search for prestructure error
                const prestructure = INFORMATION.error.prestructure;
                for (let a = 0; a < prestructure.length; a++) {
                    const err = prestructure[a]; // error object
                    if (query === err.code) {
                        searching = false;
                        error = err;
                        break;
                    }
                }
                
                // search for poststructure error
                const poststructure = INFORMATION.error.poststructure;
                for (let a = 0; a < poststructure.length; a++) {
                    const err = poststructure[a]; // error object
                    if (query === err.code) {
                        searching = false;
                        error = err;
                        break;
                    }
                }
                
                // search for parameter errors
                const parameter = INFORMATION.error.parameter;
                const paramTypes = Object.keys(parameter); // types array
                for (let a = 0; a < paramTypes.length; a++) {
                    if (searching) {
                        const params = Object.keys(parameter[paramTypes[a]]); // parameter array for type
                        for (let b = 0; b < params.length; b++) {
                            if (searching) {
                                const errors = parameter[paramTypes[a]][params[b]]; // errors array for parameter
                                for (let c = 0; c < errors.length; c++) {
                                    if (searching) {
                                        const err = errors[c]; // each error object
                                        if (query === err.code) {
                                            // found parameter error
                                            searching = false;
                                            error = err;
                                        }
                                    } else {
                                        break;
                                    }
                                }
                            } else {
                                break;
                            }
                        }
                    } else {
                        break;
                    }
                }
                
                // search for key function error
                const key_function = INFORMATION.error.key_function;
                const keyModules = Object.keys(key_function); // module array
                for (let a = 0; a < keyModules.length; a++) {
                    if (searching) {
                        const keys = Object.keys(key_function[keyModules[a]]); // key array for module
                        for (let b = 0; b < keys.length; b++) {
                            if (searching) {
                                const errors = key_function[keyModules[a]][keys[b]]; // errors array for key
                                for (let c = 0; c < errors.length; c++) {
                                    if (searching) {
                                        const err = errors[c]; // each error object
                                        if (query == err.code) {
                                            // found key error
                                            searching = false;
                                            error = err;
                                        }
                                    } else {
                                        break;
                                    }
                                }
                            } else {
                                break;
                            }
                        }
                    } else {
                        break;
                    }
                }
                
                if (!searching) { // found error
                    // build elements for display format
                    const headTitle = document.createElement('h3');
                    headTitle.innerText = 'Error Code Search';
    
                    const code = document.createElement('div');
                    code.innerText = 'Code: ' + error.code;
    
                    const description = document.createElement('div');
                    description.innerText = 'Description: ' + error.description;
    
                    resultContainer.appendChild(headTitle);
                    resultContainer.appendChild(addSpace());
                    resultContainer.appendChild(code);
                    resultContainer.appendChild(addSpace());
                    resultContainer.appendChild(description);
                    resultContainer.appendChild(addSpace());
                }
                
            } else {
                // data not found
                const err = document.createElement('div');
                err.innerText = error.dataNotFound;
                resultContainer.appendChild(err);
            }
            if (searching) {
                // data not found
                const err = document.createElement('div');
                err.innerText = error.dataNotFound;
                resultContainer.appendChild(err);
            }
        }
    }
};

async function searchReq() {
    const searchField = DOMit('searchField');
    if (searchField) {
        if (searchField.value.length === 0) {
            // empty string
            serveError(error.emptyString);
        } else {
            // test for local data
            if (Object.keys(INFORMATION).length === 0) {
                // test for internet connection
                if (window.navigator.onLine === true) {
                    // debounce to prevent excessive requests
                    clearTimeout(debounceRequest);
                    debounceRequest = setTimeout(() => {
                        // debounced
                        clearTimeout(debounceRequest);

                        // select answer field
                        const answer = DOMit('answerField');
                            
                        // start loader
                        startLoader();
            
                        // 3 cases of request
                            // Case 1: responds with answer
                            // Case 2: responds with error
                            // Case 3: connection timeout
            
                        // fetch request to Eval API
                        const root = 'https://eval-api-8ece55f267c1.herokuapp.com/';
                        const controller = new AbortController();

                        // Case 3: Connection timeout
                        const connectionTimeout = setTimeout(() => {

                            // abort request
                            controller.abort();
                            
                            // stop loader
                            stopLoader();

                            // update answer field with error message
                            serveError(error.connectionTimeout);

                            // cleanup cache
                            clearTimeout(connectionTimeout);

                        }, requestDuration);
            
                        try {
                            fetch(`${root}/eval/info`, {
                                method: 'GET',
                                signal: controller.signal,
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                            })
                            .then(response => response.json())
                            .then((data) => {
            
                                // Case 1: responds with answer

                                // cleanup cache
                                clearTimeout(connectionTimeout);

                                // store in local data structure
                                INFORMATION = data;
                                
                                // get result
                                searchResult();

                                // stop loader
                                stopLoader();

                            });
                        } catch {

                            // Case 2: responds with error
                            
                            // cancel connection timeout
                            clearTimeout(connectionTimeout);

                            // stop loader after a single duration
                            stopLoader();

                            // update answer field with error message
                            serveError(error.connectionFailed);
                        }
                    }, 1000);
                } else {
                    // highlight connection status
                    const connectionStatusDisplay = DOMit('connectionStatusDisplay');
                    if (connectionStatusDisplay) {
                        connectionStatusDisplay.style.color = '#a90d00';
                    }
                    const x = setTimeout(() => {
                        clearTimeout(x);
                        const connectionStatusDisplay = DOMit('connectionStatusDisplay');
                        if (connectionStatusDisplay) {
                            connectionStatusDisplay.style.color = '#2fff2f';
                        }
                    }, 1000);
                }
            } else {
                // just use local data to get result
                searchResult();
            }
        }
    }
};

function addSpace() {
    const space = document.createElement('br');
    return space;
};

// display initial status
if (window.navigator.onLine === true) {
    // connected
    const connectionStatusDisplay = DOMit('connectionStatusDisplay');
    if (connectionStatusDisplay) {
        connectionStatusDisplay.innerText = connectionStatus[1];
    }
} else {
    // disconnected
    const connectionStatusDisplay = DOMit('connectionStatusDisplay');
    if (connectionStatusDisplay) {
        connectionStatusDisplay.innerText = connectionStatus[0];
    }
}

// user controls

// update status on connection events
window.addEventListener('online', () => {
    // connected
    const connectionStatusDisplay = DOMit('connectionStatusDisplay');
    if (connectionStatusDisplay) {
        connectionStatusDisplay.innerText = connectionStatus[1];
    }
});

window.addEventListener('offline', () => {
    // disconnected
    const connectionStatusDisplay = DOMit('connectionStatusDisplay');
    if (connectionStatusDisplay) {
        connectionStatusDisplay.innerText = connectionStatus[0];
    }
});
const evalBTN = DOMit('evalBTN');
if (evalBTN) {
    evalBTN.addEventListener('click', evalReq);
}
document.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
        event.preventDefault();
        const inputEL = document.activeElement;
        if (inputEL.id !== null && inputEL.id !== undefined) {
            const inputID = inputEL.id;
            if (inputID === 'problem-field') {
                evalReq();
            } else if (inputID === 'search-field') {
                searchReq();
            }
        }
    }
});

// search button displays program information
const searchBTN = DOMit('searchBTN');
if (searchBTN) {
    searchBTN.addEventListener('click', searchReq);
}
